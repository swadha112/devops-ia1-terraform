import json
import boto3
import os

def handler(event, context):
    """
    Simple Lambda function that demonstrates:
    - DynamoDB interaction
    - S3 interaction 
    - Environment variables
    """

    # Initialize AWS clients (will use LocalStack endpoints)
    dynamodb = boto3.resource('dynamodb')
    s3 = boto3.client('s3')

    # Get table and bucket names from environment
    table_name = os.environ.get('DYNAMODB_TABLE', 'user-data-table')
    bucket_name = os.environ.get('S3_BUCKET')

    try:
        # Test DynamoDB connection
        table = dynamodb.Table(table_name)

        # Test S3 connection
        s3_response = s3.list_objects_v2(Bucket=bucket_name, MaxKeys=1)

        response_body = {
            'message': 'Hello from Terraform + LocalStack!',
            'environment': os.environ.get('ENVIRONMENT', 'development'),
            'dynamodb_table': table_name,
            's3_bucket': bucket_name,
            'lambda_version': context.function_version if context else 'local',
            'status': 'success'
        }

        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(response_body, indent=2)
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'message': 'Error occurred',
                'error': str(e),
                'status': 'error'
            })
        }
